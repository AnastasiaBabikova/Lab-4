﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Laba_4
{
    class Program
    {
        static void Main(string[] args)
        {
            //Цикл для повтора задачи
            do
            {
                //Переменная выбора 
                uint vvod = 0;

                //Вывод сообщения на экран
                Console.WriteLine("Выберите метод: 1-модель относительного большинства, 2-модель Борда");
                //Считывание переменной выбора, пока она не станет равной 1 или 2
                while ((vvod != 1) && (vvod != 2))
                {
                    //Считывание переменной vvod, если введенные данные имеют тип uint
                    uint.TryParse(Console.ReadLine(), out vvod);
                    //Вывод сообщения об ошибке, если vvod != 1 или vvod != 2
                    if ((vvod != 1) && (vvod != 2))
                        Console.WriteLine("Повторите попытку");
                }
                //Выбор модели относительного большинства
                if (vvod == 1)
                {
                    otnosit_bol();
                }
                if(vvod == 2)
                {
                    bord();
                }
                Console.WriteLine("Для продолжения нажмите Enter; Для выхода из программы нажмите Escape");
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape);

        }

        private static void otnosit_bol()//Модель относительного большинства
        {
            Console.WriteLine("Вы выбрали модель относительного большинства");
            Console.WriteLine("--------------------------");
            Console.WriteLine("Введите количество голосующих(избирателей)");
            int kolvo = Convert.ToInt32(Console.ReadLine());
            
            int m; //место

            int A = 0;
            int B = 0;
            int C = 0;

            List<int> nums = new List<int>();

            for (int j = 0; j < kolvo; j++)
            {
                    Console.WriteLine("Проголосуйте за одного кандидата");
                    m = Convert.ToInt32(Console.ReadLine());
                    nums.Add(m);
            }

            foreach (var item in nums)
            {
                if(item == 1)
                {
                    A = A + 1;
                }
                if(item == 2)
                {
                    B = B + 1;
                }
                if(item == 3)
                {
                    C = C + 1;
                }
            }
            
            int max = 0;

            if (A > 0)
            {
                max = A;
            }
            if (B > A)
            {
                max = B;
            }
            if (C > B)
            {
                max = C;
            }
            Console.WriteLine("A = " + A);
            Console.WriteLine("B = " + B);
            Console.WriteLine("C = " + C);
            Console.WriteLine("Победитель - " + max);

        }
      
        private static void bord()//Модель Борда
        {
            Console.WriteLine("Вы выбрали модель Борда");
            Console.WriteLine("--------------------------");

            Console.WriteLine("Введите количество голосующих(избирателей");
            int kolvo = Convert.ToInt32(Console.ReadLine());
            
            int kandidat = 3;

            int m; //место

            List<int> nums = new List<int>();

            for (int j = 0; j < kolvo; j++)
            {
                for (int i = 0; i < kandidat; i++)
                {
                    Console.WriteLine("Введите место для кандидата № " + (i + 1));
                    m = Convert.ToInt32(Console.ReadLine());
                    nums.Add(m);
                }
            }

            //Баллы
            //foreach (var item in nums)
            //{
            //    Console.WriteLine(item);
            //}
            List<int> nums_1 = new List<int>();//кандидат 1
            List<int> nums_2 = new List<int>();//кандидат 2
            List<int> nums_3 = new List<int>();//кандидат 3 
            int k = 1;
            while (nums.Count>0)// не пустой
            {
                
                var result = nums.Take(1);
                if (k == 1)//кандидат 1
                {
                    foreach (var item in result)
                    {
                        if (item == 1)//место
                        {
                            nums_1.Add(2);//балл
                        }
                        if (item == 2)//место
                        {
                            nums_1.Add(1);//балл
                        }
                        if (item == 3)//место
                        {
                            nums_1.Add(0);//балл
                        }
                        
                    }
                    nums.RemoveAt(0);
                    
                    k++;
                }
                if (k == 2)//кандидат 2
                {
                    foreach (var item in result)
                    {
                        if (item == 1)
                        {
                            nums_2.Add(2);
                        }
                        if (item == 2)
                        {
                            nums_2.Add(1);
                        }
                        if (item == 3)
                        {
                            nums_2.Add(0);
                        }
                        
                    }
                    nums.RemoveAt(0);
                    
                    k++;
                }
                if (k == 3)//кандидат 3
                {
                    foreach (var item in result)
                    {
                        if (item == 1)
                        {
                            nums_3.Add(2);
                        }
                        if (item == 2)
                        {
                            nums_3.Add(1);
                        }
                        if (item == 3)
                        {
                            nums_3.Add(0);
                        }
                    }
                    nums.RemoveAt(0);
                    
                }

                k = 1;
            }

            int A = 0;
            int B = 0;
            int C = 0;


            foreach (var item in nums_1)
            {
                A = A + item;
            }
            foreach (var item in nums_2)
            {
                B = B + item;
            }
            foreach (var item in nums_3)
            {
                C = C + item;
            }
            int max = 0;

            if (A > 0)
            {
                max = A;
            }
            if (B > A)
            {
                max = B;
            }
            if (C > B)
            {
                max = C;
            }
            Console.WriteLine("A = " + A);
            Console.WriteLine("B = " + B);
            Console.WriteLine("C = " + C);
            Console.WriteLine("Победитель - " + max);
        }
    }
}
